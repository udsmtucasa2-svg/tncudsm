import { Link } from 'react-router-dom';
import { LuChevronDown, LuArrowRight, LuLandmark, LuUsers, LuBookOpen } from 'react-icons/lu';
import PageBanner from '../components/PageBanner.jsx';
import SectionHeading from '../components/SectionHeading.jsx';
import Reveal from '../components/Reveal.jsx';
import Button from '../components/Button.jsx';
import { Icon } from '../lib/icons.jsx';
import { about } from '../data/site.js';
import { beliefGroups, story, structure } from '../data/beliefs.js';
import './About.css';

const values = [
  { icon: 'faith', title: 'Faith', text: 'Rooted in the Word of God and the Adventist message.' },
  { icon: 'users', title: 'Fellowship', text: 'A welcoming family for every student on campus.' },
  { icon: 'service', title: 'Service', text: 'Serving our campus and community with love.' },
];

const doing = [
  { icon: 'church', title: 'Worship', text: 'Sabbath School and Divine Service every Sabbath.', to: '/#worship' },
  { icon: 'evangelism', title: 'Bible study', text: 'Study the Bible with a friendly guide.', to: '/bible-study' },
  { icon: 'music', title: 'Music', text: 'Join the choir and praise teams.', to: '/choir' },
  { icon: 'medical', title: 'Health and service', text: 'Care for body, mind and community.', to: '/departments' },
];

// Section tones alternate white / light grey down the page.
export default function About() {
  const total = beliefGroups.reduce((n, g) => n + g.items.length, 0);
  let n = 0;
  const tone = () => (n++ % 2 ? 'section--soft' : '');
  let num = 0;

  return (
    <>
      <PageBanner title="About TNC" subtitle="Seventh-day Adventist Church, Public Campus Ministries" />

      {/* 1. Who we are */}
      <section className={`section ${tone()}`}>
        <div className="container container--text">
          <SectionHeading eyebrow="Who we are" title="TNC UDSM" />
          <p>TNC UDSM is the Seventh-day Adventist student fellowship at TUCASA Nyerere Campus, University of Dar es Salaam. We gather for worship, Bible study, music, health outreach and evangelism, and we support students spiritually through their university journey.</p>
          <ul className="about-facts">
            <li><LuLandmark aria-hidden="true" />Seventh-day Adventist Church</li>
            <li><LuUsers aria-hidden="true" />Public Campus Ministries</li>
            <li><LuBookOpen aria-hidden="true" />TUCASA Nyerere Campus</li>
          </ul>
        </div>
      </section>

      {/* 2. Mission, vision and values: one panel, three columns (stacked rows on phones) */}
      <section className={`section ${tone()}`}>
        <div className="container">
          <SectionHeading eyebrow="Why we exist" title="Our Mission, Vision and Values" />
          <Reveal className="mvv">
            <article className="mvv__col">
              <span className="mvv__icon"><Icon name="mission" /></span>
              <div><h3>Our Mission</h3><p>{about.mission}</p></div>
            </article>
            <article className="mvv__col">
              <span className="mvv__icon"><Icon name="vision" /></span>
              <div><h3>Our Vision</h3><p>{about.vision}</p></div>
            </article>
            <article className="mvv__col">
              <span className="mvv__icon"><Icon name="users" /></span>
              <div>
                <h3>Our Values</h3>
                <ul className="mvv__values">
                  {values.map((v) => (
                    <li key={v.title}><Icon name={v.icon} /><span><b>{v.title}.</b> {v.text}</span></li>
                  ))}
                </ul>
              </div>
            </article>
          </Reveal>
        </div>
      </section>

      {/* 3. What we believe: the 28 Fundamental Beliefs (kept at #faith for the Explore Our Faith buttons) */}
      <section className={`section ${tone()}`} id="faith">
        <div className="container container--narrow">
          <SectionHeading eyebrow="What we believe" title="Explore Our Faith" />
          <p className="lead">{about.beliefs} Our {total} Fundamental Beliefs come from the Bible. Open a group to read more.</p>
          <div className="beliefs">
            {beliefGroups.map((g, gi) => (
              <details key={g.key} className="belief-group" open={gi === 0}>
                <summary>
                  <span className="icon-tile"><Icon name={g.icon} /></span>
                  <span className="belief-group__name">{g.title}<small>{g.items.length} {g.items.length === 1 ? 'belief' : 'beliefs'}</small></span>
                  <LuChevronDown className="belief-group__chev" aria-hidden="true" />
                </summary>
                <ol className="belief-list">
                  {g.items.map(([name, text]) => {
                    num += 1;
                    return (
                      <li key={name}><span className="belief-list__num">{num}</span><div><b>{name}</b><p>{text}</p></div></li>
                    );
                  })}
                </ol>
              </details>
            ))}
          </div>
          <p className="beliefs__source">Full statements: <a href="https://www.adventist.org/beliefs/" target="_blank" rel="noreferrer">adventist.org/beliefs</a></p>
          <div className="center-row">
            <Button to="/bible-study" variant="gold" arrow>Request a Bible Study</Button>
            <Button to="/prayer-request" variant="outline">Submit a Prayer Request</Button>
          </div>
        </div>
      </section>

      {/* 4. Our story */}
      <section className={`section ${tone()}`}>
        <div className="container container--narrow">
          <SectionHeading eyebrow="Our story" title="From a Bible study movement to a worldwide family" />
          <ol className="timeline">
            {story.map((s) => (
              <li key={s.year} className="timeline__item">
                <span className="timeline__year">{s.year}</span>
                <div><h3>{s.title}</h3><p>{s.text}</p></div>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* 5. How the church is organised (a simple stepper, no cards) */}
      <section className={`section ${tone()}`}>
        <div className="container">
          <SectionHeading eyebrow="One worldwide church" title="How the Church Is Organised" />
          <p className="lead">TNC is part of a global family. Every level works together for the same mission.</p>
          <ol className="structure">
            {structure.map(([name, text], i) => (
              <li key={name} className={i === 0 ? 'is-here' : ''}>
                <span className="structure__dot">{i + 1}</span>
                <b>{name}</b>
                <span className="structure__text">{text}</span>
                {i === 0 && <em>TNC UDSM is here</em>}
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* 6. What we do (icon list, no cards) */}
      <section className={`section ${tone()}`}>
        <div className="container">
          <SectionHeading eyebrow="Get involved" title="What We Do" />
          <ul className="doing">
            {doing.map((d) => (
              <li key={d.title}>
                <Link to={d.to} className="doing__item">
                  <span className="doing__icon"><Icon name={d.icon} /></span>
                  <span className="doing__body"><b>{d.title}</b><span>{d.text}</span></span>
                  <LuArrowRight className="doing__go" aria-hidden="true" />
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* 8. Invitation */}
      <section className="about-cta">
        <div className="container about-cta__inner">
          <div><h2>You are welcome here</h2><p>Come to worship this Sabbath, or join the family online.</p></div>
          <div className="about-cta__actions">
            <Button to="/register" variant="gold" arrow>Join TNC</Button>
            <Button to="/contact" variant="light">Contact us</Button>
          </div>
        </div>
      </section>
    </>
  );
}